import { abreviacoes } from "../abreviacoes.js";
import { speakEndedEvent } from "../content.js";
import { playButtonId } from "./play-button.js";
import { velocidadeId } from "./rate.js";

let utterance;
function camelParaHifen(texto) {
  return texto
    // Adiciona um hífen antes de qualquer letra maiúscula
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    // Converte toda a string para minúsculas
    .toLowerCase();
}
async function speak(text) {
    if ('speechSynthesis' in window) {
        cancelSpeak();
        for (const [regex, substituicao] of abreviacoes) {
            text = text.replace(regex, substituicao);
        }
        const result = await chrome.storage.local.get(["voz"]);
        utterance = new SpeechSynthesisUtterance(capitalizeSentences(text));
        utterance.lang = 'pt-BR';
        utterance.rate = Number(document.getElementById(velocidadeId).value) * 0.01;
        utterance.pitch = pitch(utterance.rate);
        if (result.voz) {
            utterance.voice = speechSynthesis.getVoices()[result.voz];
        }
        utterance.addEventListener("end", (event) => {
            document.getElementById(playButtonId).dispatchEvent(speakEndedEvent);
        });
        speechSynthesis.speak(utterance);
    } else {
        console.info('Desculpe, seu navegador não suporta a API Web Speech.');
    }
}
function pitch(rate) {
    // Compensação suave
    let pitch = 1 - 0.12 * (rate - 1);

    // Limites para evitar distorção
    return Math.min(1.05, Math.max(0.9, pitch));
}

function cancelSpeak() {
    if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
    } else {
        console.info('Desculpe, seu navegador não suporta a API Web Speech.');
    }
}
function capitalizeSentences(texto) {
    return texto.replace(
        /(^|[.!?]\s+)([a-zà-ÿ])/gi,
        (_, inicio, letra) => inicio + letra.toUpperCase()
    );
}
export { speak, cancelSpeak, utterance, pitch };