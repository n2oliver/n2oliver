import { abreviacoes } from "./abreviacoes.js";

const cancelSpeak = () => {
    if ('speechSynthesis' in window) {
        speechSynthesis.cancel();
    } else {
        console.info('Desculpe, seu navegador não suporta a API Web Speech.');
    }
}

const speak = async (text) => {
    if ('speechSynthesis' in window) {
        cancelSpeak();
        for (const [regex, substituicao] of abreviacoes) {
            text = text.replace(regex, substituicao);
        }
        const result = await chrome.storage.local.get(["voz"]);
        const utterance = new SpeechSynthesisUtterance(capitalizeSentences(text));
        utterance.lang = 'pt-BR';
        utterance.rate = 1.5;
        utterance.pitch = pitch(1.5);
        if (result.voz) {
            utterance.voice = speechSynthesis.getVoices()[result.voz];
        }

        speechSynthesis.speak(utterance);
    } else {
        console.info('Desculpe, seu navegador não suporta a API Web Speech.');
    }
}
function pitch(rate) {
    const rMin = 0.5;
    const rMax = 2.0;
    const pMin = 0.5;
    const pMax = 2.0;

    return pMax - ((rate - rMin) / (rMax - rMin)) * (pMax - pMin);
}
function capitalizeSentences(texto) {
    return texto.replace(
        /(^|[.!?]\s+)([a-zà-ÿ])/gi,
        (_, inicio, letra) => inicio + letra.toUpperCase()
    );
}

export { speak, cancelSpeak };